/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package KuisTest;
import JajarG.JajarGenjang;
import Lingkaran.Lingkaran;
import PersegiPanjang.PersegiPanjang;
import Segitiga.Segitiga;
import java.util.Scanner;
import persegi.Persegi;
/**
 *
 * @author Asus X453
 */
public class KuisTest {
    public static void menu(){
        System.out.println("Masukkan menu yang di inginkan:");
        System.out.println("1. Hitung Segitiga");
        System.out.println("2. Hitung Persegi");
        System.out.println("3. Hitung Persegi Panjang");
        System.out.println("4. Hitung Lingkaran");
        System.out.println("5. Hitung Jajar Genjang");
        System.out.println("6. Keluar");
        System.out.println("----------------------------------");
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Segitiga sgt = new Segitiga();
        Persegi p = new Persegi();
        PersegiPanjang pp = new PersegiPanjang();
        Lingkaran lkr = new Lingkaran();
        JajarGenjang jg = new JajarGenjang();
        
        int Pilih;
        do{
            menu();
            Pilih = sc.nextInt();
            switch(Pilih){
                case 1:
                    System.out.println("Menghitung Segitiga");
                    sgt.setAlas(5.5f);
                    sgt.setTinggi(8.2f);
                    System.out.println("Luas Segitiga : "+sgt.getLuasSegitiga());
                    System.out.println("Keliling Segitiga : "+sgt.getKelilingSegitiga());
                    break;
                case 2: 
                    System.out.println("Menghitung Persegi");
                    p.setSisi(10);
                    System.out.println("Luas Persegi : "+p.getLuasPersegi());
                    System.out.println("Keliling Persegi : "+p.getKelilingPersegi());
                    break;
                case 3:
                    System.out.println("Menghitung Persegi Panjang");
                    pp.setPanjang(10);
                    pp.setLebar(5);
                    System.out.println("Luas Persegi Panjang : "+pp.getLuasPersegiPanjang());
                    System.out.println("Keliling Persegi Panjang : "+pp.getKelilingPersegiPanjang());
                    break;
                case 4:
                    System.out.println("Menghitung Lingkaran");
                    lkr.setjari(7.5);
                    System.out.println("Luas Lingkaran : "+lkr.getLuasLingkaran());
                    System.out.println("Keliling Lingkaran : "+lkr.getKelilingLingkaran());
                    break;
                case 5:
                    System.out.println("Menghitung Jajar Genjang");
                    jg.setAlas(5);
                    jg.setTinggi(10);
                    jg.setSisi(8);
                    System.out.println("Luas Jajar Genjang : "+jg.getLuasJajarGenjang());
                    System.out.println("Keliling Jajar Genjang : "+jg.getKelilingJajarGenjang());
                    break;
            }
        } while (Pilih != 6) ;
    }
}
